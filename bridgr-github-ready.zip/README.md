# Bridgr

A local release intelligence workspace for translating product changes into plain English for PMs and founders.

## Run

```bash
pnpm install
pnpm dev
```

## Build

```bash
pnpm build
```

The deployable site is generated in `dist`.

## Deploy

### Vercel

- Framework preset: Vite
- Build command: `pnpm build`
- Output directory: `dist`

This repo includes `vercel.json`.

### Netlify

- Build command: `pnpm build`
- Publish directory: `dist`

This repo includes `netlify.toml`.

## Optional Stitch key

Keep the key out of browser code:

```bash
export STITCH_API_KEY="your-key"
pnpm dev
```

The app only reports whether the key is present. It does not send the key to the browser.
